/*Will output "Aloha!"*/

#include <iostream>  

int main(void){
   std::cout<<"Aloha!\n"; 
   return 0;   
}

