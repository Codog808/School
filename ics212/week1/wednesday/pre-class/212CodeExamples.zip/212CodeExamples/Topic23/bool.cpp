/*change Boolean to true or false output*/

#include<iostream>

   using namespace std;

   int main(){
   
     bool b = true;
     cout<<"b = "<<boolalpha<<b<<endl;
     cout<<"b = "<<noboolalpha<<b<<endl;
            
     return 0;
   }

/*
b = true
b = 1
*/







