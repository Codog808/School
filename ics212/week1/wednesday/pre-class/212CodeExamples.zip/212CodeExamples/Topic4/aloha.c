/*
 * aloha.c
 * outputs "Aloha!" to the screen
 * Lisa Miller
 * 1/12/22
 */

#include <stdio.h>

int main(void)
{
    printf("Aloha!\n");

    return 0;
}
