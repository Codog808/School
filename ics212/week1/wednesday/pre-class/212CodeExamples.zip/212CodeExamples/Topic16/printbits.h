void printbits(unsigned int);

 
