//constants
#define MAX_ARRAY 32 //maximum array size that displays in bubblesort

//function prototypes
void loadArrayWithRandomNumbers(int[], const int, const int, const int);
void errorCheckingFirstAndLast(const int, const int);
void printarray(const int [], const int, const int);
void bubblesort(int [], const int);
int binarySearch(const int[], const int, int, int);

