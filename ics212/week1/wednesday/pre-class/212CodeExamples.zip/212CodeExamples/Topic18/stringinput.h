#define END_OF_STRING '\0'

//function prototypes
int getstring(char [], const int);
int getline2(char [], const int);
