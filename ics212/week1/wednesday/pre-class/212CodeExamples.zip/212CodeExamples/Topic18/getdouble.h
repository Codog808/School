#define MAX 100
double getdouble();

