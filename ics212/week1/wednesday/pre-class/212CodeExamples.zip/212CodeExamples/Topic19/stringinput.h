#define END_OF_STRING '\0'
int getstring(char [], const int);
int getline2(char [], const int);
