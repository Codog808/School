/*
Short description of program.
Last Name, First Name
ICS 212 Assignment #26 
Today's Date
*/ 

#include <iostream>
#include <string.h>
#include <string>
#include <fstream>
#include <vector>     //to get the vector class (a vector is a type of array)
#include <algorithm>  //to use the sort() function
#include <iomanip>    //to use the setw() function

#define SIZE  130
using namespace std;

//Used to store three strings: the English, the Japanese, and the sort field 
class Entry{
public:
//default constructor
//three set functions
//three get functions 
//overload the operator< (less than operator)
private:
//data field for English
//data field for Japanese
//data field for the sort field
};

int main(int argc, char *argv[]){
//Make a vector of Entry objects.
//Read the data from the file one line at a time
//Break the line into three parts as described on the assignment webpage. 
//Store the data for each line in an Entry object. 
//Store each Entry object in the vector.
//Sort the vector of Entry objects.
//Display the English and Japanese parts of the sorted Entry objects.
	
   return 0;
}
   
	


